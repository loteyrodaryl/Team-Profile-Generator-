# Employee s profile HTML page generator

## Description

A Node CLI that takes in information about employees and generates and HTML webpage that displays summaries for each person.

## Testing

Unit test with Jest

## Usage

Download or clone the repo and run it with node app.js in your terminal
